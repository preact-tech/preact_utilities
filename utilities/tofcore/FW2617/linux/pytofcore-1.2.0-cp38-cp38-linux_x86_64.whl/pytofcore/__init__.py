# make sure .pyd and .so files are copied to pytofcore dir before building wheels

from .pytofcore import *